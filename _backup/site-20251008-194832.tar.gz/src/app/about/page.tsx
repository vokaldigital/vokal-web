export default function AboutPage() {
  return (
    <main className="min-h-screen grid place-items-center">
      <h1 className="text-4xl text-white">About</h1>
    </main>
  );
}