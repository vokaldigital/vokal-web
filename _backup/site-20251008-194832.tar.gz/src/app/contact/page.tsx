export default function contactPage() {
  return (
    <main className="min-h-screen grid place-items-center">
      <h1 className="text-4xl text-white">Contact</h1>
    </main>
  );
}