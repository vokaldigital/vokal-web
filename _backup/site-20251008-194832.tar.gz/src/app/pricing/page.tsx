// src/app/pricing/page.tsx
export default function PricingPage() {
  return (
    <main className="min-h-screen grid place-items-center">
      <h1 className="text-4xl text-white">Pricing</h1>
    </main>
  );
}