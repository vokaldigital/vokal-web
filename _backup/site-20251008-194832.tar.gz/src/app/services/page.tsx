export default function ServicesPage() {
  return (
    <main className="min-h-screen grid place-items-center">
      <h1 className="text-4xl text-white">Services</h1>
    </main>
  );
}