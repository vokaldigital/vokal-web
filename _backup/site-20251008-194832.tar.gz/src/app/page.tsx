// src/app/page.tsx
export default function Home() {
  return (
    <main className="hero">
      <div className="hero-inner">
        <h1 className="headline">
          Your Brand.<span className="block highlight">Louder.</span>
        </h1>

        <p className="sub">
          AI-Driven Strategy for Business Growth and Recognition.
        </p>

        <form className="lead" action="/contact" id="contact">
          <input
            type="email"
            name="email"
            placeholder="Your email"
            required
            aria-label="Your email"
          />
          <button
            type="submit"
            className="flex h-14 min-w-[160px] items-center justify-center rounded-full bg-black/75 px-8 text-base font-medium text-white transition-colors hover:bg-black hover:text-[#abff03]"
          >
            Get Started
          </button>
        </form>
      </div>
    </main>
  );
}
