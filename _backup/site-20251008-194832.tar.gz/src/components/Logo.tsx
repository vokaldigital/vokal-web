// src/components/Logo.tsx
import Image from "next/image";
import clsx from "clsx";

type LogoProps = {
  className?: string;
};

export function Logo({ className }: LogoProps) {
  return (
    <Image
      src="/logo.svg"
      alt="Vokal"
      width={120}
      height={32}
      priority
      className={clsx("h-8 w-auto", className)}
    />
  );
}
