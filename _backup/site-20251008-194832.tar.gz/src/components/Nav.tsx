// src/components/Nav.tsx
"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { Logo } from "./Logo";

const navItems = [
  { name: "Services", href: "#services" },
  { name: "Work", href: "#work" },
  { name: "About", href: "#about" },
  { name: "Contact", href: "#contact" },
];

export default function Nav() {
  const [isOpen, setIsOpen] = useState(false);

  const toggleMenu = () => setIsOpen((open) => !open);
  const closeMenu = () => setIsOpen(false);

  return (
    <nav className="sticky top-4 z-50 w-full px-4">
      <div className="mx-auto max-w-5xl rounded-[28px] bg-slate-950/70 backdrop-blur-2xl backdrop-saturate-150">
        <div className="px-5 py-2 sm:px-6 md:px-8 md:py-3">
          <div className="flex h-14 items-center justify-between md:h-16">
            {/* Logo */}
            <div className="flex-shrink-0">
              <Link href="/" className="flex items-center gap-2 text-white" aria-label="Vokal home">
                <Logo className="h-8 w-auto text-white" />
              </Link>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="flex items-center gap-8">
                {navItems.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="relative text-white transition-colors duration-200 hover:text-[#abff03] after:absolute after:bottom-0 after:left-1/2 after:h-[2px] after:w-full after:-translate-x-1/2 after:origin-center after:scale-x-0 after:bg-[#abff03] after:transition-transform after:duration-300 hover:after:scale-x-100"
                  >
                    {item.name}
                  </Link>
                ))}
                <Link
                  href="#contact"
                  className="rounded-full bg-black/75 px-6 py-2 text-white transition-colors duration-200 hover:bg-black hover:text-[#abff03]"
                >
                  Get Started
                </Link>
              </div>
            </div>

            {/* Mobile toggle */}
            <div className="md:hidden">
              <button
                type="button"
                onClick={toggleMenu}
                className="inline-flex h-10 w-10 items-center justify-center rounded-2xl bg-black/40 text-white transition-colors hover:bg-black/55"
                aria-label="Toggle menu"
                aria-expanded={isOpen}
              >
                {isOpen ? <X size={22} /> : <Menu size={22} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isOpen && (
            <div className="mt-3 rounded-2xl bg-slate-950/80 p-3 md:hidden">
              <div className="flex flex-col gap-2">
                {navItems.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    onClick={closeMenu}
                    className="px-2 py-2 text-white transition-colors hover:text-[#abff03]"
                  >
                    {item.name}
                  </Link>
                ))}
                <Link
                  href="#contact"
                  onClick={closeMenu}
                  className="rounded-full bg-black/75 px-6 py-2 text-center text-white transition-colors duration-200 hover:bg-black hover:text-[#abff03]"
                >
                  Get Started
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}
